package builder;

public class Exercito {
    private SoldadoBuilder soldadoBuilder;

    public Exercito(SoldadoBuilder soldadoBuilder) {
        this.soldadoBuilder = soldadoBuilder;
    }

    public void construirSoldado(){
        soldadoBuilder.adicionar_helicoptero();
        soldadoBuilder.adicionar_kit();
    }

    public void getSoldado(){
        soldadoBuilder.mostrarSoldado();
    }

    public void setSoldadoBuilder(SoldadoBuilder sb){
        soldadoBuilder = sb;
        construirSoldado();
    }
}
