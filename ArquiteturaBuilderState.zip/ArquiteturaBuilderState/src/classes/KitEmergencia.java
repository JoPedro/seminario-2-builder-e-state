package classes;

public class KitEmergencia {
    String itens[] = {"Dipirona","Estetoscópio","Esfigmomanômetro","Analgésico","Soro"};
    public String info(){
        String info = "";
        for (int i = 0; i < itens.length;i++){
            if(i != itens.length-1){
                info += itens[i]+",";
            }else{
                info += itens[i];
            }
        }
        return info;
    }
}
