package classes;

public class Helicoptero {
    public int misseis, percentual_combustivel;
    public String modelo;

    public Helicoptero() {
        this.misseis = 2;
        this.percentual_combustivel = 100;
        this.modelo = "Apache AH-64";
    }

    public String info(){
        String info = "Helicóptero "+modelo+" tem "+misseis+" misseís e possui "
                +percentual_combustivel+" de combustível";
        return info;
    }
}
