package builder;

import classes.Soldado;

public abstract class SoldadoBuilder {
    public Soldado soldado;

    public SoldadoBuilder() {
        this.soldado = new Soldado();
    }

    public abstract void adicionar_kit();
    public abstract void adicionar_helicoptero();
    public abstract void resetar_soldado();
    public abstract void mostrarSoldado();
    public Soldado getSoldado(){
        return soldado;
    }
}
