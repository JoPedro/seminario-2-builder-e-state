import builder.Exercito;
import classes.SoldadoMedico;
import classes.SoldadoPiloto;

public class Main {
    public static void main(String[] args) {
        Exercito exercito = new Exercito(new SoldadoMedico());
        exercito.construirSoldado();
        exercito.getSoldado();

        Exercito fab = new Exercito(new SoldadoPiloto());
        fab.construirSoldado();
        fab.getSoldado();
    }
}
