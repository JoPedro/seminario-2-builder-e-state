package classes;

public class Soldado {
    public int vida = 100;
    public KitEmergencia kit;
    public boolean arma = true;
    public Helicoptero heli;
}
