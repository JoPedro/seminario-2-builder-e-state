package classes;

import builder.SoldadoBuilder;

public class SoldadoPiloto extends SoldadoBuilder {
    @Override
    public void adicionar_kit() {
        soldado.kit = null;
    }

    @Override
    public void adicionar_helicoptero() {
        soldado.heli = new Helicoptero();
    }

    @Override
    public void resetar_soldado() {
        soldado = new Soldado();
    }

    @Override
    public void mostrarSoldado() {
        System.out.println("Tipo: Piloto");
        System.out.println("Vida: "+this.soldado.vida+"%");
        System.out.print("Responsável pelo helicóptero: ");
        System.out.println(this.soldado.heli.info());
    }
}
