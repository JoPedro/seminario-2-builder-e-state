package classes;

import builder.SoldadoBuilder;

public class SoldadoMedico extends SoldadoBuilder {

    @Override
    public void adicionar_kit() {
        soldado.kit = new KitEmergencia();
    }

    @Override
    public void adicionar_helicoptero() {
        soldado.heli = null;
    }

    public void resetar_soldado(){
        soldado = new Soldado();
    }

    @Override
    public void mostrarSoldado() {
        System.out.println("Tipo: Médico");
        System.out.println("Vida: "+this.soldado.vida+"%");
        System.out.print("Possui um kit com esses itens: ");
        System.out.println(soldado.kit.info());
    }

}
